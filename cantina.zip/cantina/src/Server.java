import java.io.*;
import java.net.InetSocketAddress;
import java.security.MessageDigest;
import java.sql.*;
import java.util.*;
import com.sun.net.httpserver.*;

public class Server {
    static String DB_URL  = System.getenv().getOrDefault("DB_URL",  "jdbc:mysql://localhost:3306/cantina?useSSL=false&serverTimezone=UTC");
    static String DB_USER = System.getenv().getOrDefault("DB_USER", "root");
    static String DB_PASS = System.getenv().getOrDefault("DB_PASS", "infra1230");
    static int PORT = Integer.parseInt(System.getenv().getOrDefault("PORT","8000"));

    public static void main(String[] args) throws Exception {
        System.out.println("Iniciando servidor...");
        System.out.println("DB_URL="+DB_URL+" DB_USER="+DB_USER+" PORT="+PORT);

        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);

        server.createContext("/", new PaginaEstaticas("web/index.html"));
        server.createContext("/index.html", new PaginaEstaticas("web/index.html"));
        server.createContext("/login.html", new PaginaEstaticas("web/login.html"));
        server.createContext("/cadastro.html", new PaginaEstaticas("web/cadastro.html"));
        server.createContext("/aluno.html", new PaginaEstaticas("web/aluno.html"));
        server.createContext("/operador-login.html", new PaginaEstaticas("web/operador-login.html"));
        server.createContext("/operador.html", new PaginaEstaticas("web/operador.html"));
        server.createContext("/styles.css", new PaginaEstaticas("web/styles.css"));

        server.createContext("/api/products", new ListarSalgados());
        server.createContext("/api/user/register", new CadastrarAluno());
        server.createContext("/api/user/login", new LoginAluno());
        server.createContext("/api/order/create", new CriarPedido());
        server.createContext("/api/orders", new ListarPedidos());
        server.createContext("/api/order/status", new ConsultarPedido());
        server.createContext("/api/order/update", new AtualizarStatusPedido());
        server.createContext("/api/notifications", new ListarNotificacoes());
        server.createContext("/api/product/update", new AtualizarEstoque());
        server.createContext("/api/debug", new DepuracaoSistema());

        server.setExecutor(null);
        server.start();
        System.out.println("Servidor iniciado em http://localhost:" + PORT);
        System.out.println("Endpoint debug: http://localhost:" + PORT + "/api/debug");
    }

    static Connection getConn() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
    }

    static Map<String,String> parseForm(InputStream is) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String l;
        while ((l = br.readLine()) != null) sb.append(l);
        String body = sb.toString();
        Map<String,String> map = new HashMap<>();
        if (body.length() == 0) return map;
        String[] pairs = body.split("&");
        for (String p : pairs) {
            String[] kv = p.split("=",2);
            String k = java.net.URLDecoder.decode(kv[0], "UTF-8");
            String v = kv.length>1 ? java.net.URLDecoder.decode(kv[1], "UTF-8") : "";
            map.put(k, v);
        }
        return map;
    }

    static String readFile(String path) throws Exception {
        InputStream is = new FileInputStream(path);
        BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String l;
        while ((l = br.readLine()) != null) sb.append(l).append("\n");
        return sb.toString();
    }

    static String sha256(String s) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] b = md.digest(s.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte by : b) sb.append(String.format("%02x", by));
        return sb.toString();
    }

    static class PaginaEstaticas implements HttpHandler {
        String file;
        PaginaEstaticas(String file) { this.file = file; }

        public void handle(HttpExchange ex) throws IOException {
            String path = ex.getRequestURI().getPath();
            String f = file;
            if (path.endsWith(".html")) f = "web" + path;
            if (path.endsWith(".css")) f = "web" + path;
            if (path.endsWith(".js")) f = "web" + path;
            try {
                byte[] bytes = readFile(f).getBytes("UTF-8");
                String ct = "text/html; charset=utf-8";
                if (path.endsWith(".css")) ct = "text/css; charset=utf-8";
                if (path.endsWith(".js")) ct = "application/javascript; charset=utf-8";
                ex.getResponseHeaders().set("Content-Type", ct);
                ex.sendResponseHeaders(200, bytes.length);
                OutputStream os = ex.getResponseBody();
                os.write(bytes);
                os.close();
            } catch (Exception e) {
                String msg = "Not found";
                ex.sendResponseHeaders(404, msg.length());
                OutputStream os = ex.getResponseBody();
                os.write(msg.getBytes());
                os.close();
            }
        }
    }

    static class ListarSalgados implements HttpHandler {
        public void handle(HttpExchange ex) throws IOException {
            try (Connection c = getConn()) {
                PreparedStatement ps = c.prepareStatement("SELECT id,nome,preco,quantidade FROM salgados");
                ResultSet rs = ps.executeQuery();
                StringBuilder sb = new StringBuilder();
                sb.append("[");
                boolean first = true;
                while (rs.next()) {
                    if (!first) sb.append(",");
                    sb.append("{");
                    sb.append("\"id\":").append(rs.getInt("id")).append(",");
                    sb.append("\"name\":\"").append(rs.getString("nome")).append("\",");
                    sb.append("\"price\":").append(rs.getBigDecimal("preco")).append(",");
                    sb.append("\"quantity\":").append(rs.getInt("quantidade"));
                    sb.append("}");
                    first = false;
                }
                sb.append("]");
                byte[] out = sb.toString().getBytes("UTF-8");
                ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                ex.sendResponseHeaders(200,out.length);
                ex.getResponseBody().write(out);
                ex.getResponseBody().close();
            } catch (Exception e) {
                String msg = "{\"error\":\""+e.getMessage().replace("\"","'")+"\"}";
                byte[] out = msg.getBytes("UTF-8");
                ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                ex.sendResponseHeaders(500,out.length);
                ex.getResponseBody().write(out);
                ex.getResponseBody().close();
            }
        }
    }

    static class CadastrarAluno implements HttpHandler {
        public void handle(HttpExchange ex) throws IOException {
            try {
                Map<String,String> form = parseForm(ex.getRequestBody());
                String email = form.getOrDefault("email","");
                String password = form.getOrDefault("password","");
                if (email.isEmpty()||password.isEmpty()) {
                    String msg = "{\"error\":\"missing\"}";
                    byte[] out = msg.getBytes("UTF-8");
                    ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                    ex.sendResponseHeaders(400,out.length);
                    ex.getResponseBody().write(out);
                    ex.getResponseBody().close();
                    return;
                }
                String hash = sha256(password);
                try (Connection c = getConn()) {
                    PreparedStatement ps = c.prepareStatement("INSERT INTO alunos(nome,email,senha_hash) VALUES(?,?,?)", Statement.RETURN_GENERATED_KEYS);
                    ps.setString(1, email);
                    ps.setString(2, email);
                    ps.setString(3, hash);
                    ps.executeUpdate();
                    ResultSet rk = ps.getGeneratedKeys();
                    rk.next();
                    int userId = rk.getInt(1);
                    String resp = "{\"success\":true,\"userId\":"+userId+"}";
                    byte[] out = resp.getBytes("UTF-8");
                    ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                    ex.sendResponseHeaders(200,out.length);
                    ex.getResponseBody().write(out);
                    ex.getResponseBody().close();
                }
            } catch (SQLException sqle) {
                String msg = "{\"error\":\"email_exists\"}";
                try {
                    byte[] out = msg.getBytes("UTF-8");
                    ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                    ex.sendResponseHeaders(409,out.length);
                    ex.getResponseBody().write(out);
                    ex.getResponseBody().close();
                } catch (Exception e){}
            } catch (Exception e) {
                String msg = "{\"error\":\""+e.getMessage().replace("\"","'")+"\"}";
                byte[] out = msg.getBytes("UTF-8");
                ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                ex.sendResponseHeaders(500,out.length);
                ex.getResponseBody().write(out);
                ex.getResponseBody().close();
            }
        }
    }

    static class LoginAluno implements HttpHandler {
        public void handle(HttpExchange ex) throws IOException {
            try {
                Map<String,String> form = parseForm(ex.getRequestBody());
                String email = form.getOrDefault("email","");
                String password = form.getOrDefault("password","");
                if (email.isEmpty()||password.isEmpty()) {
                    String msg = "{\"error\":\"missing\"}";
                    byte[] out = msg.getBytes("UTF-8");
                    ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                    ex.sendResponseHeaders(400,out.length);
                    ex.getResponseBody().write(out);
                    ex.getResponseBody().close();
                    return;
                }
                String hash = sha256(password);
                try (Connection c = getConn()) {
                    PreparedStatement ps = c.prepareStatement("SELECT id,email,nome FROM alunos WHERE email=? AND senha_hash=?");
                    ps.setString(1, email);
                    ps.setString(2, hash);
                    ResultSet rs = ps.executeQuery();
                    if (!rs.next()) {
                        String msg = "{\"error\":\"invalid\"}";
                        byte[] out = msg.getBytes("UTF-8");
                        ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                        ex.sendResponseHeaders(401,out.length);
                        ex.getResponseBody().write(out);
                        ex.getResponseBody().close();
                        return;
                    }
                    int userId = rs.getInt("id");
                    String respToken = UUID.randomUUID().toString();
                    PreparedStatement ps2 = c.prepareStatement("INSERT INTO sessoes(token,aluno_id) VALUES(?,?)");
                    ps2.setString(1, respToken);
                    ps2.setInt(2, userId);
                    ps2.executeUpdate();
                    String name = rs.getString("nome");
                    String resp = "{\"token\":\""+respToken+"\",\"userId\":"+userId+",\"email\":\""+email+"\",\"name\":\""+name+"\"}";
                    byte[] out = resp.getBytes("UTF-8");
                    ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                    ex.sendResponseHeaders(200,out.length);
                    ex.getResponseBody().write(out);
                    ex.getResponseBody().close();
                }
            } catch (Exception e) {
                String msg = "{\"error\":\""+e.getMessage().replace("\"","'")+"\"}";
                byte[] out = msg.getBytes("UTF-8");
                ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                ex.sendResponseHeaders(500,out.length);
                ex.getResponseBody().write(out);
                ex.getResponseBody().close();
            }
        }
    }

    static Integer userIdFromToken(Connection c, String token) throws Exception {
        if (token == null || token.isEmpty()) return null;
        PreparedStatement ps = c.prepareStatement("SELECT aluno_id FROM sessoes WHERE token=?");
        ps.setString(1, token);
        ResultSet rs = ps.executeQuery();
        if (!rs.next()) return null;
        return rs.getInt(1);
    }

    static String userEmailFromToken(Connection c, String token) throws Exception {
        Integer uid = userIdFromToken(c, token);
        if (uid == null) return null;
        PreparedStatement ps = c.prepareStatement("SELECT email FROM alunos WHERE id=?");
        ps.setInt(1, uid);
        ResultSet rs = ps.executeQuery();
        if (!rs.next()) return null;
        return rs.getString(1);
    }

    static String userNameFromToken(Connection c, String token) throws Exception {
        Integer uid = userIdFromToken(c, token);
        if (uid == null) return null;
        PreparedStatement ps = c.prepareStatement("SELECT nome FROM alunos WHERE id=?");
        ps.setInt(1, uid);
        ResultSet rs = ps.executeQuery();
        if (!rs.next()) return null;
        return rs.getString(1);
    }

    static class CriarPedido implements HttpHandler {
        public void handle(HttpExchange ex) throws IOException {
            try {
                Map<String,String> form = parseForm(ex.getRequestBody());
                String token = form.getOrDefault("token","");
                String student_name = form.getOrDefault("student_name","");
                String student_email = form.getOrDefault("student_email","");
                String items = form.getOrDefault("items","");
                if (items == null || items.trim().isEmpty()) {
                    String msg = "{\"error\":\"no_items\"}";
                    byte[] out = msg.getBytes("UTF-8");
                    ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                    ex.sendResponseHeaders(400,out.length);
                    ex.getResponseBody().write(out);
                    ex.getResponseBody().close();
                    return;
                }

                try (Connection c = getConn()) {
                    if ((student_name.isEmpty() || student_email.isEmpty()) && token != null && !token.isEmpty()) {
                        String em = userEmailFromToken(c, token);
                        String nm = userNameFromToken(c, token);
                        if (em != null) student_email = em;
                        if (nm != null) student_name = nm;
                    }

                    List<String[]> parsed = new ArrayList<>();
                    String[] parts = items.split(";");
                    for (String p : parts) {
                        if (p.trim().isEmpty()) continue;
                        String[] comp = p.split(":");
                        if (comp.length < 3) continue;
                        String name = java.net.URLDecoder.decode(comp[0], "UTF-8");
                        int qty = Integer.parseInt(comp[1]);
                        double price = Double.parseDouble(comp[2]);
                        parsed.add(new String[]{name,String.valueOf(qty),String.valueOf(price)});
                    }
                    if (parsed.isEmpty()) {
                        String msg = "{\"error\":\"invalid_items\"}";
                        byte[] out = msg.getBytes("UTF-8");
                        ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                        ex.sendResponseHeaders(400,out.length);
                        ex.getResponseBody().write(out);
                        ex.getResponseBody().close();
                        return;
                    }

                    c.setAutoCommit(false);

                    PreparedStatement psCheck = c.prepareStatement("SELECT id,quantidade FROM salgados WHERE nome = ? FOR UPDATE");
                    for (String[] it : parsed) {
                        String pname = it[0];
                        int need = Integer.parseInt(it[1]);
                        psCheck.setString(1, pname);
                        ResultSet rs = psCheck.executeQuery();
                        if (!rs.next()) {
                            c.rollback();
                            String msg = "{\"error\":\"product_not_found\",\"product\":\""+pname+"\"}";
                            byte[] out = msg.getBytes("UTF-8");
                            ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                            ex.sendResponseHeaders(400,out.length);
                            ex.getResponseBody().write(out);
                            ex.getResponseBody().close();
                            return;
                        }
                        int avail = rs.getInt("quantidade");
                        if (avail < need) {
                            c.rollback();
                            String msg = "{\"error\":\"insufficient_stock\",\"product\":\""+pname+"\",\"available\":"+avail+"}";
                            byte[] out = msg.getBytes("UTF-8");
                            ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                            ex.sendResponseHeaders(409,out.length);
                            ex.getResponseBody().write(out);
                            ex.getResponseBody().close();
                            return;
                        }
                    }

                    double total = 0.0;
                    for (String[] it : parsed) {
                        int qty = Integer.parseInt(it[1]);
                        double price = Double.parseDouble(it[2]);
                        total += qty * price;
                    }

                    PreparedStatement psOrder = c.prepareStatement(
                        "INSERT INTO pedidos(nome_aluno,email_aluno,total,status) VALUES(?,?,?,?)",
                        Statement.RETURN_GENERATED_KEYS
                    );
                    psOrder.setString(1, student_name);
                    psOrder.setString(2, student_email);
                    psOrder.setBigDecimal(3, new java.math.BigDecimal(total).setScale(2, java.math.RoundingMode.HALF_UP));
                    psOrder.setString(4, "pedido em preparação");
                    psOrder.executeUpdate();
                    ResultSet rk = psOrder.getGeneratedKeys();
                    rk.next();
                    int orderId = rk.getInt(1);

                    PreparedStatement psi = c.prepareStatement(
                        "INSERT INTO itens_pedido(pedido_id,nome_salgado,quantidade,preco) VALUES(?,?,?,?)"
                    );
                    PreparedStatement pUpdateStock = c.prepareStatement(
                        "UPDATE salgados SET quantidade = quantidade - ? WHERE nome = ?"
                    );
                    for (String[] it : parsed) {
                        String pname = it[0];
                        int qty = Integer.parseInt(it[1]);
                        double price = Double.parseDouble(it[2]);

                        psi.setInt(1, orderId);
                        psi.setString(2, pname);
                        psi.setInt(3, qty);
                        psi.setBigDecimal(4, new java.math.BigDecimal(price).setScale(2, java.math.RoundingMode.HALF_UP));
                        psi.addBatch();

                        pUpdateStock.setInt(1, qty);
                        pUpdateStock.setString(2, pname);
                        pUpdateStock.addBatch();
                    }
                    psi.executeBatch();
                    pUpdateStock.executeBatch();

                    PreparedStatement pn1 = c.prepareStatement("INSERT INTO notificacoes(destinatario,mensagem) VALUES(?,?)");
                    pn1.setString(1, student_email);
                    pn1.setString(2, "Pedido #"+orderId+" recebido e em preparação");
                    pn1.executeUpdate();
                    pn1.setString(1, "operador");
                    pn1.setString(2, "Novo pedido #"+orderId+" recebido");
                    pn1.executeUpdate();

                    c.commit();

                    String resp = "{\"success\":true,\"orderId\":"+orderId+"}";
                    byte[] out = resp.getBytes("UTF-8");
                    ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                    ex.sendResponseHeaders(200,out.length);
                    ex.getResponseBody().write(out);
                    ex.getResponseBody().close();
                }
            } catch (Exception e) {
                try { ex.getResponseBody().close(); } catch (Exception exx) {}
                String msg = "{\"error\":\""+e.getMessage().replace("\"","'")+"\"}";
                byte[] out = msg.getBytes("UTF-8");
                ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                try {
                    ex.sendResponseHeaders(500,out.length);
                    ex.getResponseBody().write(out);
                    ex.getResponseBody().close();
                } catch (Exception ignore) {}
            }
        }
    }

    static class ListarPedidos implements HttpHandler {
        public void handle(HttpExchange ex) throws IOException {
            try (Connection c = getConn()) {
                PreparedStatement ps = c.prepareStatement(
                    "SELECT id,nome_aluno,email_aluno,total,status,criado_em FROM pedidos ORDER BY criado_em DESC"
                );
                ResultSet rs = ps.executeQuery();
                StringBuilder sb = new StringBuilder();
                sb.append("[");
                boolean first = true;
                while (rs.next()) {
                    if (!first) sb.append(",");
                    sb.append("{");
                    sb.append("\"id\":").append(rs.getInt("id")).append(",");
                    sb.append("\"student_name\":\"").append(rs.getString("nome_aluno")).append("\",");
                    sb.append("\"student_email\":\"").append(rs.getString("email_aluno")).append("\",");
                    sb.append("\"total\":").append(rs.getBigDecimal("total")).append(",");
                    sb.append("\"status\":\"").append(rs.getString("status")).append("\",");
                    sb.append("\"created_at\":\"").append(rs.getTimestamp("criado_em")).append("\"");
                    sb.append("}");
                    first = false;
                }
                sb.append("]");
                byte[] out = sb.toString().getBytes("UTF-8");
                ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                ex.sendResponseHeaders(200,out.length);
                ex.getResponseBody().write(out);
                ex.getResponseBody().close();
            } catch (Exception e) {
                String msg = "{\"error\":\""+e.getMessage().replace("\"","'")+"\"}";
                byte[] out = msg.getBytes("UTF-8");
                ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                ex.sendResponseHeaders(500,out.length);
                ex.getResponseBody().write(out);
                ex.getResponseBody().close();
            }
        }
    }

    static class ConsultarPedido implements HttpHandler {
        public void handle(HttpExchange ex) throws IOException {
            try (Connection c = getConn()) {
                String q = ex.getRequestURI().getQuery();
                int id = 0;
                if (q != null) {
                    for (String s : q.split("&")) {
                        String[] kv = s.split("=");
                        if (kv[0].equals("id")) id = Integer.parseInt(kv[1]);
                    }
                }

                PreparedStatement ps = c.prepareStatement(
                    "SELECT id,nome_aluno,email_aluno,total,status,criado_em FROM pedidos WHERE id=?"
                );
                ps.setInt(1,id);
                ResultSet rs = ps.executeQuery();
                if (!rs.next()) {
                    String msg = "{\"error\":\"not found\"}";
                    byte[] out = msg.getBytes("UTF-8");
                    ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                    ex.sendResponseHeaders(404,out.length);
                    ex.getResponseBody().write(out);
                    ex.getResponseBody().close();
                    return;
                }

                StringBuilder sb = new StringBuilder();
                sb.append("{");
                sb.append("\"id\":").append(rs.getInt("id")).append(",");
                sb.append("\"student_name\":\"").append(rs.getString("nome_aluno")).append("\",");
                sb.append("\"student_email\":\"").append(rs.getString("email_aluno")).append("\",");
                sb.append("\"total\":").append(rs.getBigDecimal("total")).append(",");
                sb.append("\"status\":\"").append(rs.getString("status")).append("\",");
                sb.append("\"created_at\":\"").append(rs.getTimestamp("criado_em")).append("\",");

                PreparedStatement psi = c.prepareStatement(
                    "SELECT nome_salgado,quantidade,preco FROM itens_pedido WHERE pedido_id=?"
                );
                psi.setInt(1,id);
                ResultSet ri = psi.executeQuery();
                sb.append("\"items\":[");
                boolean f = true;
                while (ri.next()) {
                    if (!f) sb.append(",");
                    sb.append("{");
                    sb.append("\"product_name\":\"").append(ri.getString("nome_salgado")).append("\",");
                    sb.append("\"qty\":").append(ri.getInt("quantidade")).append(",");
                    sb.append("\"price\":").append(ri.getBigDecimal("preco"));
                    sb.append("}");
                    f = false;
                }
                sb.append("]");
                sb.append("}");

                byte[] out = sb.toString().getBytes("UTF-8");
                ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                ex.sendResponseHeaders(200,out.length);
                ex.getResponseBody().write(out);
                ex.getResponseBody().close();
            } catch (Exception e) {
                String msg = "{\"error\":\""+e.getMessage().replace("\"","'")+"\"}";
                byte[] out = msg.getBytes("UTF-8");
                ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                ex.sendResponseHeaders(500,out.length);
                ex.getResponseBody().write(out);
                ex.getResponseBody().close();
            }
        }
    }

    static class AtualizarStatusPedido implements HttpHandler {
        public void handle(HttpExchange ex) throws IOException {
            try {
                Map<String,String> form = parseForm(ex.getRequestBody());
                int id = Integer.parseInt(form.getOrDefault("id","0"));
                String status = form.getOrDefault("status","");
                try (Connection c = getConn()) {
                    PreparedStatement ps = c.prepareStatement("UPDATE pedidos SET status=? WHERE id=?");
                    ps.setString(1,status);
                    ps.setInt(2,id);
                    ps.executeUpdate();

                    PreparedStatement pn = c.prepareStatement("SELECT email_aluno FROM pedidos WHERE id=?");
                    pn.setInt(1,id);
                    ResultSet r = pn.executeQuery();
                    String email = "unknown";
                    if (r.next()) email = r.getString(1);

                    PreparedStatement pnot = c.prepareStatement(
                        "INSERT INTO notificacoes(destinatario,mensagem) VALUES(?,?)"
                    );
                    pnot.setString(1,email);
                    pnot.setString(2,"Pedido #"+id+" - "+status);
                    pnot.executeUpdate();
                    pnot.setString(1,"operador");
                    pnot.setString(2,"Pedido #"+id+" atualizado para "+status);
                    pnot.executeUpdate();

                    String resp = "{\"success\":true}";
                    byte[] out = resp.getBytes("UTF-8");
                    ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                    ex.sendResponseHeaders(200,out.length);
                    ex.getResponseBody().write(out);
                    ex.getResponseBody().close();
                }
            } catch (Exception e) {
                String msg = "{\"error\":\""+e.getMessage().replace("\"","'")+"\"}";
                byte[] out = msg.getBytes("UTF-8");
                ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                ex.sendResponseHeaders(500,out.length);
                ex.getResponseBody().write(out);
                ex.getResponseBody().close();
            }
        }
    }

    static class ListarNotificacoes implements HttpHandler {
        public void handle(HttpExchange ex) throws IOException {
            try (Connection c = getConn()) {
                String q = ex.getRequestURI().getQuery();
                String recipient = "";
                if (q != null) {
                    for (String s : q.split("&")) {
                        String[] kv = s.split("=");
                        if (kv[0].equals("recipient")) recipient = kv.length>1?java.net.URLDecoder.decode(kv[1],"UTF-8"):"";
                    }
                }

                PreparedStatement ps = c.prepareStatement(
                    "SELECT id,destinatario,mensagem,criado_em,lida FROM notificacoes WHERE destinatario=? ORDER BY criado_em DESC"
                );
                ps.setString(1, recipient.isEmpty()?"operador":recipient);
                ResultSet rs = ps.executeQuery();

                StringBuilder sb = new StringBuilder();
                sb.append("[");
                boolean first = true;
                while (rs.next()) {
                    if (!first) sb.append(",");
                    sb.append("{");
                    sb.append("\"id\":").append(rs.getInt("id")).append(",");
                    sb.append("\"recipient\":\"").append(rs.getString("destinatario")).append("\",");
                    sb.append("\"message\":\"").append(rs.getString("mensagem")).append("\",");
                    sb.append("\"created_at\":\"").append(rs.getTimestamp("criado_em")).append("\",");
                    sb.append("\"seen\":").append(rs.getBoolean("lida"));
                    sb.append("}");
                    first = false;
                }
                sb.append("]");

                byte[] out = sb.toString().getBytes("UTF-8");
                ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                ex.sendResponseHeaders(200,out.length);
                ex.getResponseBody().write(out);
                ex.getResponseBody().close();
            } catch (Exception e) {
                String msg = "{\"error\":\""+e.getMessage().replace("\"","'")+"\"}";
                byte[] out = msg.getBytes("UTF-8");
                ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                ex.sendResponseHeaders(500,out.length);
                ex.getResponseBody().write(out);
                ex.getResponseBody().close();
            }
        }
    }

    static class AtualizarEstoque implements HttpHandler {
        public void handle(HttpExchange ex) throws IOException {
            try {
                if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
                    String msg = "{\"error\":\"method_not_allowed\"}";
                    byte[] out = msg.getBytes("UTF-8");
                    ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                    ex.sendResponseHeaders(405,out.length);
                    ex.getResponseBody().write(out);
                    ex.getResponseBody().close();
                    return;
                }

                Map<String,String> form = parseForm(ex.getRequestBody());
                int id = Integer.parseInt(form.getOrDefault("id", "0"));
                int quantity = Integer.parseInt(form.getOrDefault("quantity", "0"));
                double price = Double.parseDouble(form.getOrDefault("price", "0"));

                if (id <= 0 || quantity < 0 || price <= 0) {
                    String msg = "{\"error\":\"invalid_params\"}";
                    byte[] out = msg.getBytes("UTF-8");
                    ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                    ex.sendResponseHeaders(400,out.length);
                    ex.getResponseBody().write(out);
                    ex.getResponseBody().close();
                    return;
                }

                try (Connection c = getConn()) {
                    PreparedStatement ps = c.prepareStatement("UPDATE salgados SET quantidade=?, preco=? WHERE id=?");
                    ps.setInt(1, quantity);
                    ps.setBigDecimal(2, new java.math.BigDecimal(price).setScale(2, java.math.RoundingMode.HALF_UP));
                    ps.setInt(3, id);
                    int updated = ps.executeUpdate();
                    if (updated == 0) {
                        String msg = "{\"error\":\"not_found\"}";
                        byte[] out = msg.getBytes("UTF-8");
                        ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                        ex.sendResponseHeaders(404,out.length);
                        ex.getResponseBody().write(out);
                        ex.getResponseBody().close();
                        return;
                    }
                    String resp = "{\"success\":true}";
                    byte[] out = resp.getBytes("UTF-8");
                    ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                    ex.sendResponseHeaders(200,out.length);
                    ex.getResponseBody().write(out);
                    ex.getResponseBody().close();
                }
            } catch (Exception e) {
                String msg = "{\"error\":\""+e.getMessage().replace("\"","'")+"\"}";
                byte[] out = msg.getBytes("UTF-8");
                ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
                try {
                    ex.sendResponseHeaders(500,out.length);
                    ex.getResponseBody().write(out);
                    ex.getResponseBody().close();
                } catch (Exception ignore) {}
            }
        }
    }

    static class DepuracaoSistema implements HttpHandler {
        public void handle(HttpExchange ex) throws IOException {
            StringBuilder outSb = new StringBuilder();
            outSb.append("{");
            try (Connection c = getConn()) {
                outSb.append("\"db_ok\":true,");

                PreparedStatement p1 = c.prepareStatement("SELECT COUNT(*) FROM alunos");
                ResultSet r1 = p1.executeQuery();
                r1.next();
                outSb.append("\"users_count\":").append(r1.getInt(1)).append(",");

                PreparedStatement p2 = c.prepareStatement("SELECT COUNT(*) FROM salgados");
                ResultSet r2 = p2.executeQuery();
                r2.next();
                outSb.append("\"products_count\":").append(r2.getInt(1)).append(",");

                PreparedStatement p3 = c.prepareStatement("SELECT COUNT(*) FROM pedidos");
                ResultSet r3 = p3.executeQuery();
                r3.next();
                outSb.append("\"orders_count\":").append(r3.getInt(1));
            } catch (Exception e) {
                outSb.append("\"db_ok\":false,");
                outSb.append("\"error\":\"").append(e.getMessage().replace("\"","'")).append("\"");
            }
            outSb.append("}");

            byte[] out = outSb.toString().getBytes("UTF-8");
            ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
            try {
                ex.sendResponseHeaders(200,out.length);
                ex.getResponseBody().write(out);
                ex.getResponseBody().close();
            } catch (Exception ignore){}
        }
    }
}
